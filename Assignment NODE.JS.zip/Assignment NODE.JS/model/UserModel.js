'user strict';
var connection = require('./../mysqlConnection.js');
var bcrypt = require('bcryptjs');
var async = require('async');
var crypto = require('crypto');
const jwt = require("jsonwebtoken");
var fs = require('fs');
const { json } = require('express');
var moment = require('moment');

var User = function () {

}
User.loginUsers = function (req, res) {

    try {
        // console.log('req--------------------------->>', req.body);
        var email = req.body.logindata.username;
        var password = req.body.logindata.password;
        let ipAddress = req.body.ipAddress
        var algorithm = 'aes256'; // or any other algorithm supported by OpenSSL
        var key = 'password';
        var text = password;
        var query = `SELECT * FROM file_users WHERE EMAIL = '${email}'`;
        connection.query(query, (error, results) => {
            if (error) {
                console.log("error ocurred", error);
                res(null, {
                    "code": 400,
                    "failed": "error ocurred"
                })
            } else {

                if (results.length > 0) {
                    // console.log('login credentials Found');
                    var decipher = crypto.createDecipher(algorithm, key);
                    var decryptedPassword = decipher.update(results[0].PASSWORD, 'hex', 'utf8') + decipher.final('utf8');
                    // console.log('pw---', decryptedPassword);
                    if (decryptedPassword == password) {
                        let data = {
                            Email: email,
                            Password: password
                        }
                        const token = jwt.sign({ userData: data }, "mykey", { expiresIn: "3 hours" });
                        var query = `insert into user_log (EMAIL,PASSWORD,TOKEN,IP_ADDRESS) values ('${email}','${results[0].PASSWORD}','${token}','${ipAddress}')`;

                        connection.query(query, (error, result) => {
                            // console.log(result)
                            if (error || result.length == 0) {
                                console.log("error: ", error);
                                //results(error,null);  
                                var json = {
                                    status: 500
                                }
                                res(null, json)
                            } else {
                                res(null, {
                                    "code": 200,
                                    "success": "login successful",
                                    "Token": token,
                                    "email": email
                                });
                            }
                        });
                    }
                    else {
                        //   res.status(200).send({access_token: token})
                        res(null, {
                            "code": 204,
                            "success": "Email and password does not match"

                        });
                    }
                }
                else {
                    res(null, {
                        "code": 204,
                        "success": "Email does not exits"
                    });
                }
            }
        });

    } catch (error) {
        console.log('error----->>>', error);
    }


}
User.register = function (request, results) {
    try {
        // console.log('inside register--------------->>>', request.body);
        let password = request.body.userdata.password
        var newpassword = bcrypt.hashSync(password, 8);
        let input = request.body.userdata;
        let FirstName = input.firstName;
        let LastName = input.lastName;
        let Email = input.username;
        let Password = input.password;
        let IP_ADRESS = request.body.ipAddress;
        var algorithm = 'aes256'; // or any other algorithm supported by OpenSSL
        var key = 'password';
        var text = password;
        var cipher = crypto.createCipher(algorithm, key);
        var encryptedPassword = cipher.update(text, 'utf8', 'hex') + cipher.final('hex');

        async.waterfall(
            [
                function (callback) {
                    var checkUserQuery = `SELECT * FROM file_users WHERE EMAIL = '${Email}'`;
                    connection.query(checkUserQuery, (err, res1) => {
                        if (err) console.log("Err", err);
                        else callback(null, res1);
                    });
                },
                function (res1, callback) {
                    // console.log('arg1------------>>>>', res1.length);
                    if (res1.length > 0) {
                        // useralreadyExist;
                        var json = {
                            status: 'user_already_Exist'
                        }
                        callback(null, json)

                    } else {
                        var insertUserQuery = `INSERT INTO file_users (USER_NAME,PASSWORD, EMAIL, IP_ADDRESS)
                    VALUES ('${FirstName}','${encryptedPassword}', '${Email}', '${IP_ADRESS}');`;
                        connection.query(insertUserQuery, (err, result) => {
                            if (err) console.log("Err", err);
                            else callback(null, result); {
                                var finalResult = result;
                            }
                        });

                    }

                }

            ],
            function (err, finalResult) {
                // console.log('res2------------------------------>>>>', finalResult);
                results(null, finalResult);
            }
        );













    } catch (error) {
        console.log('error-------->>>', error);
    }
    // console.log(JSON.stringify(request.body))

}

User.fileUpload = function (request, results) {
    try {

        let files = request.files;
        let token = request.body.Token;
        let email = request.body.Email;
        for (let i = 0; i < files.length; i++) {

            let File = request.files.length ? `/public/uploads/${(files[i].filename)}` : '';
            jwt.verify(token, 'mykey', (err, authData) => {
                if (err) {
                    json = {
                        status: 'Forbidden'
                    }
                    results(null, json);
                } else {
                    // console.log('token matched---------------->>>');
                    var query = `insert into filedata (FILE) values ('${File}')`;
                    // console.log('query---->>>', query);
                    connection.query(query, (error, result) => {
                        if (error) console.log(" error :" + error)
                        else {
                            console.log("RESULT IS  : " + result);
                            if (i == files.length - 1) {
                                var json = {
                                    success: true,
                                    statusCode: 200
                                }
                                results(null, json);
                            }
                        }
                    });


                }
            });

        }

    } catch (error) {
        console.log('error----->>>', error);
    }
}

User.getFiles = function (request, results) {
    try {

        var query = `select * from filedata`;
        connection.query(query, (error, result) => {
            if (error) console.log("List section error :" + error)
            else {

                var json = {
                    responseResult: result
                }
                results(null, json);
            }
        })
    } catch (error) {
        console.log('error----->>>', error);
    }
}

User.deleteFile = function (request, results) {
    try {
        // console.log('inside deleteFile--->>>', request.body);
        let ID = request.body.ID
        let Token = request.body.Token
        let email = request.body.Email

        jwt.verify(Token, 'mykey', (err, authData) => {
            if (err) {
                // console.log('error-------send 403');
                json = {
                    status: 'Forbidden'
                }
                results(null, json);
            } else {
                // console.log('token matched -------');

                var query = `delete from filedata where ID='${ID}'`;
                // console.log('query---->>>', query);
                connection.query(query, (error, result) => {
                    if (error) console.log("List section error :" + error)
                    else {
                        console.log("RESULT IS  : " + result);

                        var json = {
                            responseResult: result
                        }
                        results(null, json);
                    }
                })


            }
        })
    } catch (error) {
        console.log('error----->>>', error);
    }
}


module.exports = User;