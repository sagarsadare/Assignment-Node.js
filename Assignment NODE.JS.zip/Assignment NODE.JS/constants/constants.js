exports.STATUS_SUCCESS = "success";
exports.STATUS_FAILURE = "failure";

exports.HOST = 'localhost';
exports.USER = 'root';
exports.PASSWORD = '1234';
exports.DATABASE = 'erpsys_db';

