const express = require('express');
const fs = require('fs');
var app = express();
const router = express.Router();
var multer = require('multer');
var crypto = require('crypto');
let User = require('../controller/UserController');

var fileStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        console.log("Body of multer :", req.files)
            var foldername = 'public/uploads/'
            // try {
            if (fs.existsSync(foldername)) {
                cb(null, 'public/uploads')
            } else {
                fs.mkdirSync(foldername)
                console.log('Directory Created Successfully ')
                console.log('FILE INSERTED IN PROJ_CODE :')
                cb(null, 'public/uploads/design/')
            }
        
    },
    filename: function (req, file, cb) {
        console.log('====================================');
        console.log("Approutes : ", file);
        console.log('====================================');
        if (file.originalname) {
            crypto.pseudoRandomBytes(16, function (err, res) {
                if (err) return cb(err)
                cb(null, new Date().getTime() + '--' + file.originalname)
            })
        } else {
            cb(null, '')
        }
    }
});
var fileUploadDir = multer({ storage: fileStorage });

// ********* User Routes **************
router.route('/login').post(User.login);
// router.route('/test').post(User.testTokenCheck);
router.route('/register').post(User.register);
router.route('/getFiles').post(User.get_Files);
router.route('/deleteFile').post(User.delete_File);
router.route('/fileUpload').post(fileUploadDir.any(), User.file_Upload);

module.exports = router;
